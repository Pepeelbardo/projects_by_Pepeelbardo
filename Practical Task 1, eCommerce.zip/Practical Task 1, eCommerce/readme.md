# ArtisanHub (AuthLog) — Django eCommerce Application

A multi-vendor marketplace built with Django. Buyers can browse products from
multiple stores, manage a cart, check out, and leave reviews. Vendors can create
stores and manage their own products. Includes full authentication, role-based
permissions, and password recovery.

## Apps

- **grabsomore** — authentication: register, login, logout, password reset with
  expiring single-use tokens.
- **eCommerce** — stores, products, cart, checkout, orders, and reviews.

## Prerequisites

- Python 3.10+
- MariaDB (or another MySQL-compatible server)
- `pkg-config` and the MySQL client libraries (needed to build `mysqlclient`)

On macOS with Homebrew:

```bash
brew install pkg-config mysql-client mariadb
brew services start mariadb
```

## Installation

1. Create and activate a virtual environment:

   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

2. If `mysqlclient` fails to build, export these first (Homebrew's `mysql-client`
   is keg-only and not on the default library path):

   ```bash
   export PKG_CONFIG_PATH="/opt/homebrew/opt/mysql-client/lib/pkgconfig"
   export LDFLAGS="-L/opt/homebrew/opt/mysql-client/lib"
   export CPPFLAGS="-I/opt/homebrew/opt/mysql-client/include"
   ```

3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

## Environment variables

Copy `.env.example` to `.env` and fill in real values. `.env` is not committed
to version control.

```
SECRET_KEY=your-secret-key-here
DEBUG=True
DB_NAME=ecommerce_db
DB_USER=your-db-user
DB_PASSWORD=your-db-password
DB_HOST=localhost
EMAIL_BACKEND=django.core.mail.backends.console.EmailBackend
```

Using the console email backend prints password-reset and invoice emails to the
terminal instead of sending real emails — useful for local testing.

## Database setup

1. Log in to MariaDB as root (on a fresh Homebrew install, root has no password
   and uses socket auth, so use `sudo`):

   ```bash
   sudo mysql -u root
   ```

2. Create the database and an application user:

   ```sql
   CREATE DATABASE ecommerce_db;
   CREATE USER 'your-db-user'@'localhost' IDENTIFIED BY 'your-db-password';
   GRANT ALL PRIVILEGES ON ecommerce_db.* TO 'your-db-user'@'localhost';
   FLUSH PRIVILEGES;
   EXIT;
   ```

3. Use those same values in your `.env` file.

## Running the project

```bash
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Applying migrations also creates the `Vendors` and `Buyers` groups with their
default permissions (via a data migration in the `eCommerce` app), so roles
work immediately after a fresh install.

Visit `http://127.0.0.1:8000/` to register or log in, and
`http://127.0.0.1:8000/admin/` to access the Django admin panel with your
superuser account.

## Usage

**Authentication (`grabsomore` app)**

- Register at `/register/`, choosing "Buyer" or "Vendor".
- Log in / out at `/`.
- Request a password reset at `/request-password-reset/`; the reset link
  (printed to the console with the default email backend) expires after 5
  minutes and can only be used once.

**Buyer flow (`eCommerce` app)**

- Browse the catalog at `/ecommerce/`.
- View a product's details, add it to the cart, and leave a review at
  `/ecommerce/product/<id>/`.
- Manage the cart and confirm a purchase at `/ecommerce/cart/`. Checkout
  re-validates stock, creates an order, decreases stock, empties the cart, and
  emails an invoice.
- View past orders at `/ecommerce/orders/`.

**Vendor flow (`eCommerce` app)**

- Manage stores at `/ecommerce/vendor/stores/` (visible only to users in the
  `Vendors` group).
- Manage a store's products at `/ecommerce/vendor/stores/<id>/products/`.
- All edit/delete actions check both the Django permission and store/product
  ownership, so a vendor can only manage their own stores and products.

## Project structure

```
AuthLog/
├── AuthLog/
│   ├── settings.py          # Project settings (reads DB/email config from .env)
│   ├── urls.py
│   └── wsgi.py
├── grabsomore/               # Authentication app
│   ├── models.py             # ResetToken
│   ├── views.py
│   ├── templates/
│   └── urls.py
├── eCommerce/                 # eCommerce app
│   ├── models.py             # Store, Product, Review, Order, OrderItem
│   ├── views.py
│   ├── migrations/           # includes a data migration that creates the
│   │                          # Vendors/Buyers groups and their permissions
│   ├── templates/
│   └── urls.py
├── manage.py
├── requirements.txt
├── .env.example
└── readme.md
```

## Troubleshooting

- **`ModuleNotFoundError: No module named 'django'`** — the virtual environment
  isn't activated, or `Django` is missing from `requirements.txt`.
- **`error: externally-managed-environment`** when running `pip install` — you're
  trying to install into the system Python. Use a virtual environment instead.
- **`Access denied for user 'root'@'localhost'` (error 1698)** — MariaDB's root
  account uses socket authentication. Log in with `sudo mysql -u root` instead
  of a password.
- **404 on `/accounts/login/`** — make sure `LOGIN_URL = 'grabsomore:login'` is
  set in `settings.py`; without it, Django's `@login_required` decorator falls
  back to a URL this project doesn't have.
- **`Product.MultipleObjectsReturned` when changing a price by name** — two
  products from different stores share the same name. Use the vendor panel
  (`/ecommerce/vendor/stores/<id>/products/`) to edit a specific product by ID
  instead of the name-based "Change Price" page.
